const { invoke } = require("./handler");

(async () => {
  await invoke();
})();
