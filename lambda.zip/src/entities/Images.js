const AWS = require("aws-sdk");
AWS.config.update({ region: "us-east-1" });
const dotenv = require("dotenv").config();

class Images {
  constructor() {}

  async uploadImage(body) {
    const S3_Bucket = process.env.BUCKET;

    const s3 = new AWS.S3();
    const fileName = body.fileName;
    const fileType = body.fileType;
    const s3Params = {
      Bucket: S3_Bucket,
      Key: fileName,
      Expires: 500,
      ContentType: fileType,
      ACL: "public-read",
    };

    const imageURL = await s3.getSignedUrl("putObject", s3Params);
    const result = {
      signedRequest: imageURL,
      url: `https://${S3_Bucket}.s3.amazonaws.com/${fileName}`,
    };
    return result;
  }
}

module.exports = Images;
